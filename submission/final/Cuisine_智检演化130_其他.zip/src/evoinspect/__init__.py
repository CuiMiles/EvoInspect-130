"""EvoInspect-130 research toolkit."""

__version__ = "0.1.0"
